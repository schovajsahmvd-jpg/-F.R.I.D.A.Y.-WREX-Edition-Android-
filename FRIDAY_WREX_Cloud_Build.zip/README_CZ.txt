F.R.I.D.A.Y. – WREX Edition (Android Studio starter)

CO JE HOTOVÉ
- Nativní Kotlin + Jetpack Compose HUD obrazovka.
- Viditelný foreground microphone service a oznámení s akcí Vypnout poslech.
- Základní české rozpoznávání řeči přes Android SpeechRecognizer.
- Český Android TextToSpeech.
- Retrofit rozhraní a datové modely pro HTTPS backend.
- Android Manifest s potřebnými oprávněními.

DŮLEŽITÁ OMEZENÍ
1. Toto je vývojový STARTER PROJEKT, ne hotové APK. Otevři složku v Android Studiu a sestav ji tam.
2. SpeechRecognizer není garantovaný nepřetržitý hotword engine. Opakované spouštění může být přerušeno Androidem, službou Google, výrobcem nebo zamčením telefonu. Pro spolehlivé „Ahoj Friday“ je potřeba specializovaný offline hotword engine a testování na konkrétním zařízení.
3. Android 14+ omezuje spuštění mikrofonní foreground služby: uživatel musí aplikaci otevřít a poslech výslovně zapnout, když je aplikace viditelná. Aplikace nemůže tajně zapnout mikrofon ze zamčené obrazovky.
4. showWhenLocked/turnScreenOn samo o sobě neopravňuje službu svévolně otevřít obrazovku. Android omezuje spouštění aktivit z pozadí.
5. Redmi A5 může mít jinou verzi Androidu/HyperOS podle regionu a aktualizací. Ověř ji v Nastavení > O telefonu.
6. OWNER jméno/ID v požadavku není bezpečné ověření vlastníka. Backend musí ověřovat přihlášení (např. Firebase Auth) a OWNER roli serverově. Nikdy nevěř ID poslanému samotným klientem.
7. FridayApi.kt obsahuje ukázkovou URL. Nahraď ji vlastní HTTPS adresou backendu. Bez backendu AI odpovědi nefungují.
8. Pro produkci doplň zpracování akcí, ověření odpovědi serveru, stav UI podle skutečného běhu služby, testy a zásady ochrany soukromí.

SESTAVENÍ
- Otevři složku FRIDAY_WREX_Android v Android Studiu.
- Nech Gradle dokončit synchronizaci.
- Build > Build Bundle(s) / APK(s) > Build APK(s).
- Uděl APK jen pro vlastní testování. Pro publikaci je potřeba další testování a správné zásady ochrany soukromí.

Backend JSON příklad:
POST /assistant
{
  "ownerId": "slavek-schovajsa",
  "transcript": "Kolik je 2 plus 2?",
  "device": "Xiaomi Redmi A5"
}
Odpověď:
{
  "text": "Čtyři.",
  "action": null,
  "packageName": null,
  "volume": null
}
