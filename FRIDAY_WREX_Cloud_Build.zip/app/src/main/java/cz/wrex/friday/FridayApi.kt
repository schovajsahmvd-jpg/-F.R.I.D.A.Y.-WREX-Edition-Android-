package cz.wrex.friday

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST

data class FridayRequest(
    val ownerId: String,
    val transcript: String,
    val device: String = "Xiaomi Redmi A5"
)

data class FridayResponse(
    val text: String,
    val action: String? = null,
    val packageName: String? = null,
    val volume: Int? = null
)

interface FridayApi {
    @POST("assistant")
    suspend fun ask(@Body request: FridayRequest): FridayResponse

    companion object {
        // Nahraď adresou svého HTTPS backendu. Nedávej sem tajný API klíč.
        private const val BASE_URL = "https://YOUR-DOMAIN.example/"

        fun create(): FridayApi = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(FridayApi::class.java)
    }
}
