package cz.wrex.friday

import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

private val Background = Color(0xFF0A0A0C)
private val Orange = Color(0xFFFF6F00)

class MainActivity : ComponentActivity() {
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result[Manifest.permission.RECORD_AUDIO] == true) {
            FridayMicService.start(this)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var listening by remember { mutableStateOf(false) }
            MaterialTheme(colorScheme = darkColorScheme(
                background = Background, surface = Color(0xFF151518),
                primary = Orange, onPrimary = Color.Black
            )) {
                Surface(Modifier.fillMaxSize(), color = Background) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("F.R.I.D.A.Y.", color = Orange, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                            Text("WREX EDITION  •  ONLINE INTERFACE", color = Color.LightGray, fontSize = 11.sp)
                        }
                        val transition = rememberInfiniteTransition(label = "reactor")
                        val pulse by transition.animateFloat(
                            initialValue = 0.92f, targetValue = if (listening) 1.12f else 1.0f,
                            animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
                            label = "pulse"
                        )
                        Box(
                            Modifier.size(220.dp).scale(pulse)
                                .background(Orange.copy(alpha = if (listening) 0.16f else 0.07f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Box(Modifier.size(155.dp).background(Color(0xFF20150D), CircleShape),
                                contentAlignment = Alignment.Center) {
                                Text(if (listening) "POSLOUCHÁM" else "PŘIPRAVENA",
                                    color = Orange, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            }
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Button(
                                onClick = {
                                    if (listening) {
                                        FridayMicService.stop(this@MainActivity)
                                        listening = false
                                    } else {
                                        val permissions = arrayOf(
                                            Manifest.permission.RECORD_AUDIO,
                                            Manifest.permission.POST_NOTIFICATIONS
                                        )
                                        val missing = permissions.filter {
                                            ContextCompat.checkSelfPermission(this@MainActivity, it) != PackageManager.PERMISSION_GRANTED
                                        }
                                        if (missing.isEmpty()) {
                                            FridayMicService.start(this@MainActivity)
                                            listening = true
                                        } else {
                                            permissionLauncher.launch(missing.toTypedArray())
                                            listening = true
                                        }
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Orange)
                            ) {
                                Text(if (listening) "VYPNOUT MIKROFON" else "ZAPNOUT MIKROFON",
                                    color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                            Spacer(Modifier.height(12.dp))
                            Text("Aktivace: „Ahoj F.R.I.D.A.Y.“", color = Color.LightGray, fontSize = 13.sp)
                        }
                        Text("VYTVOŘIL SLÁVEK SCHOVAJSA – WREX",
                            color = Orange, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}
